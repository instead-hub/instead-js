-- Эпизод 1.

--гостиница:
----у входа в гостицу.
----ресепшн.
----1 этаж.
------лифт.
------подсобка.
----2 этаж.
------душевая.
------номер 205.
------номер 206.
------номер 207.
----подвал.
------каморка.

--почтовое отделение.

--завод.
----проходная.
----территория завода.
----внутри здания №5
------отдел кадров.
------кабинет №2.
------кабинет №4.
------кабинет №26.
------приёмная директора.
----внутри здания №84.
------лаборатория НПС.
------лаборатория МУИ.
------лаборатория ИРП.
------секретная комната.


-- *** *** *** *** *** --
--       Локации       --
-- *** *** *** *** *** --

endOfGame = room {
	nam = 'игра окончена';
	dsc = [[Отдав артефакт почтовому работнику, я, с чувством выполненного долга, собрался на выход. Но дорогу мне преградили две высоких фигуры в чёрной одежде.^^
	-- Мы хотим поговорить с вами.^^
	-- Но я не знаю вас. И вообще мне пора идти.^^
	-- Вам некуда больше спешить.^^]];
};

safeRoom = room {
	nam = 'сейф';
	dsc = 'В стену вмонтирован сейф. На его дверке изображены планеты. В центре, видимо, Солнце. Дальше - остальные. Ха. Да такой сейф может открыть любой ребёнок.';
	way = {'room206'};
	obj = { vobj('continue','{Попробовать открыть сейф}') },
	act = function()
		walk('openingSafeDlg');
	end,
}: disable();

labNPS = room {
	nam = 'лаборатория НПС';
	dsc = 'Лаборатория "непознанного потока сознания". Название интригует.';
	obj = {'cat',
			'redButton',
			'socket'};
	way = {'building84'};
};

labMUI = room {
	nam = 'лаборатория МУИ';
	dsc = 'Лаборатория "материализации умственных идей". Название интригует.';
	obj = {'codeLock',
			'turn_screw',
			'spanner'};
	way = {'building84'};
};

labIRP = room {
	nam = 'лаборатория ИРП';
	dsc = 'Лаборатория "использования разработок на практике". Название интригует.';
	obj = {'unknownDevice'};
	way = {'building84'};
};

board = room {
	nam = 'доска объявлений';
	dsc = 'Вся доска заклеена различными объявлениями.';
	obj = {'boardPUP',
			'boardPoems',
			'boardVacancies'};
	way = {'enterToFactory'};
};

enterToFactory = room {
	nam = 'проходная завода';
	dsc = 'Проходная завода "Другой путь". На территорию просто так не попадёшь. Здесь расположен КПП. Рядом - доска объявлений.';
	obj = {'security',
			'securityWithPaper'};
	way = {'enterToTheHotel', 'board', 'factory', 'stall'};
}: disable();

factory = room {
	nam = 'территория завода';
	dsc = 'Я на территории завода. На улице никого. Около меня есть здания №5 и №84.';
	way = {'enterToFactory', 'building5', 'building84'};
}: disable();

building5 = room {
	nam = 'внутри здания №5';
	dsc = 'Люди хаотично носятся туда-сюда с различными бумагами. Здесь расположены: отдел кадров, приёмная директора и кабинеты №2, №4 и №26.';
	way = {'factory', 'cabinet2', 'cabinet4', 'cabinet26', 'personnelDepartment', 'receptionDirector'};
};

secretRoom = room {
	nam = 'секретная комната';
	dsc = 'Я попал в секретную комнату.';
	obj = {'artifact'};
};

cabinet2 = room {
	nam = 'кабинет №2';
	dsc = 'Судя по добротному дубовому столу, это кабинет важного начальника.';
	way = {'building5'};
};

cabinet4 = room {
	nam = 'кабинет №4';
	dsc = 'Судя по добротному дубовому столу, это кабинет важного начальника.';
	way = {'building5'};
};

cabinet26 = room {
	nam = 'кабинет №26';
	dsc = 'Судя по добротному дубовому столу, это кабинет важного начальника.';
	way = {'building5'};
};

personnelDepartment = room {
	nam = 'отдел кадров';
	dsc = [[Сюда стоит огромная очередь. Из кабинета слышно как тётка, видимо работник отдела кадров, кричит:^^
	-- Почему без даты?! Кто дату-то будет ставить?! Я что ли?!]];
	way = {'building5'};
};

receptionDirector = room {
	nam = 'приёмная директора';
	dsc = 'В приёмной стоит стол с компьютером и шкаф с бумагами. Справа массивная дверь в кабинет директора. Она закрыта.';
	obj = {'secretary',
	'extension'};
	way = {'building5'};
};

building84 = room {
	nam = 'внутри здания №84';
	dsc = 'Изредка мимо меня проходят люди в белых халатах с задумчивым выражением на лице. Отсюда можно пройти в "лабораторию НПС", "лабораторию МУИ" и "лабораторию ИРП".';
	exit = function(s, t)
		if t == factory and have(chair) then
			p 'Что-то не хочется мне шарахаться по территории со стулом. Оставлю его здесь.';
			drop(chair);
		end;
	end;
	obj = {'chair',
			'doctor'};
	way = {'factory', 'labNPS', 'labMUI', 'labIRP'};
};

room206 = room {
	nam = 'номер 206';
	var {
		isVisited = false;	-- Посещался ли уже этот номер. Да/Нет. true/false.
	};
	enter = function(s, f)
		if have(roomKeys) then
			if not s.isVisited then
				p 'Я открыл дверь одним из ключей со связки.';
				s.isVisited = true;
			end;
		else
			p 'Дверь заперта на замок.';
			return false;
		end;
	end;
	obj = {'picture',
			'pictureOnTheFloor'};
	dsc = 'В номере творится невообразимый хаос. Бельё с кровати скинуто на пол. Везде валяются пустые бутылки. Стены утыканы бычками.';
	way = {'floor2', 'safeRoom'};
};

bathroom = room {
	nam = 'душевая';
	obj = {'shower',
			'waterHeater'};
	way = {'floor2', 'ambry'};
	enter = function(s, f)
		if not have('pollen') then
			p 'Дверь в душевую закрыта. Судя по звукам льющейся воды - там занято.';
			return false;
		end;
	end;
	dsc = 'Душевая. На стене справа есть небольшой шкафчик.';
};

ambry = room {
	nam = 'шкафчик';
	obj = {'craneCold',
			'craneHot',
			'waterSwitch1',
			'waterSwitch2',
			'craneColdShare',
			'craneHotShare',
			'ambryTable'};
	dsc = 'Внутри нагромождение труб с кранов.';
	way = {'bathroom'};
};

room205 = room {
	nam = 'номер 205';
	dsc = 'Я в своём номере. Обстановка спартанская, но нам не привыкать.';
	way = {'floor2'};
	obj = {'flower',
			'blinds',
			'coil'};
};

floor2 = room {
	nam = '2 этаж';
	dsc = 'Я нахожусь на втором этаже гостиницы. Где-то здесь должен быть мой номер. Также тут есть душевая, лифт и несколько номеров. В конце коридора есть лестница на 1 этаж.';
	way = {'floor1', 'room205', 'room206', 'bathroom'};
	obj = {'room207'};
};

storeroom = room {
	nam = 'подсобка';
	dsc = 'Подсобное помещение. Творящийся здесь бардак трудно описать словами.';
	way = {'floor1'};
	enter = function(s, f)
		if not have('respirator') then
			p 'Я приоткрыл дверь в подсобку, но сильный запах перегара заставил меня отступить.';
			return false;
		else
			p 'Я одел противогаз и смело зашёл внутрь.';
		end;
	end;
	exit = function()
		if have(fullGlass) then
			p 'Я выпил содержимое стакана. Не выливать же его, на самом-то деле.';
			take ('emptyGlass');
			remove ('fullGlass', me() );
			fullGlass.step = fullGlass.step + 1;
		end;
		p 'Я вышел из подсобки, снял противогаз и, подумав, закрыл за собой дверь.';
		if fullGlass.step > 0 then
				p 'Выйдя из помещения, я моментально протрезвел.';
				fullGlass.step = 0;
		end;
	end;
	obj = {'alcoholMashine',
			'emptyGlass',
			'body',
			'romantik',
			'unknownSwitch'};
};

den = room {
	nam = 'каморка';
	dsc = function()
		if switch.status then
			p 'В помещении горит слабый свет от лампы. Он освещает стеллажи с многочисленными полками.';
		else
			p 'Небольшое помещение. Что-то вроде склада. Здесь царит приятный полумрак.';
		end;
	end;
	way = {'vault'};
	obj = {'switch',
			'lampSocket',
			'respirator'};
};

vault = room {
	nam = 'подвал';
	dsc = 'Похоже, я в подвале. Рядом с лифтом есть какая-то каморка.';
	way = {'lift', 'den'};
};

lift = room {
	nam = 'лифт';
	var {
		whereAmI = 1;
	};
	dsc = 'Я в лифте. Тут довольно живописно: народная роспись по стенам, бычки на полу и ощущение наступившей анархии. На стене имеются кнопки. Точнее то, что от них осталось.';
	obj = {'button1Lift',
			'button2Lift',
			'buttonDownLift'};
	way = { vroom('выйти из лифта (1 этаж)', 'floor1'): enable(),
			vroom('выйти из лифта (подвал)', 'vault'): disable() };
};

floor1 = room {
	nam = '1 этаж';
	dsc = 'Я нахожусь в коридоре с несколькими дверьми. Отсюда можно пройти в подсобку и на ресепшн. Также тут расположен лифт. В конце коридора есть лестница на 2 этаж.';
	exit = function(s, t)
		if t == floor2 and cleaningManager.ok ~= 'ok' then
			p 'Я не могу пройти. Бабуля-уборщица раскорячилась на весь проход.';
			return false;
		end;
	end;
	way = {'reception',
			'lift',
			'storeroom',
			'floor2'};
	obj = {'cleaningManager'};
};

enterToTheHotel = room {
	nam = 'у входа в гостиницу';
	dsc = 'Я нахожусь у входа в гостиницу. Отсюда можно попасть в почтовое отделение.';
	obj = {'title',
			'boy',
			'fountain',
			'advert',
			'womanAdministratorNearFountain'};
	way = {'reception',
			'postOffice',
			'enterToFactory'};
};

postOffice = room {
	nam = 'почтовое отделение';
	var {
		isEnd = 'no';
	};
	dsc = 'Обычное среднестатистическое почтовое отделение. На небольшом столике в углу навалены книги и журналы.';
	way = {'enterToTheHotel'};
	obj = {'postManager',
		'exampleBlank',
		'pen',
		'childrenBook'};
	exit = function(s, f)
		if s.isEnd == 'yes' and f == enterToTheHotel then
			walk('endOfGame');
			return false;
		end;
	end;
};

stall = room {
	nam = 'ларёк';
	dsc = 'Ларёк "Пиво и соки". В клетке сидит кролик.';
	way = {'enterToFactory'};
	obj = {'illusionist'};
};

reception = room {
	nam = 'ресепшн';
	dsc = 'Ресепшн. Обычный такой. Отечественный ресепшн.';
	exit = function(s, t)
		if t == floor1 and not have(roomKey) then
			p '-- Куда попёрся-то?! Вход только для постояльцев!';
			return false;
		end;
	end;
	enter = function(s, t)
		if not unknownSwitch.status then
			p 'С улицы доносятся чудные трёхэтажные переливы на пару с пожеланиями близких отношений в особо извращённых формах.';
		end;
	end;
	way = {'enterToTheHotel',
			'floor1'};
	obj = {'womanAdministrator',
			'roomKeys',
			'bag'};
};
