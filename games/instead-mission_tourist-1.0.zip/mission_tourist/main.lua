-- $Name:Миссия <Турист>$
-- $Version: 1.0$
-- $Author: Ordos$

instead_version "2.2.7"
require "para"
require "dash"
require "quotes"
-- require "dbg" -- Режим Debug выключен.
require "xact"
require "hideinv"

-- Подключаем файлы.
dofile "ep1_loc.lua"
dofile "ep1_obj.lua"
dofile "ep1_dlg.lua"
dofile "ep1_prs.lua"
dofile "ep1_etc.lua"

game.act = 'Не работает.';
game.use = 'Это здесь не поможет.';
game.inv = 'Зачем мне это?';

main = room {
	nam = 'Миссия "Турист"';
	forcedsc = true;
	dsc = [[-- Вызывали?^^
	-- Да. Проходи, садись. Ты когда в последний раз в отпуске был?^^
	-- Да буквально недавно - года 3 назад. А что случилось-то?^^
	-- Да вот подумал я тут на досуге... Потом ещё подумал... Ну и решил отправить тебя отдохнуть на недельку. Работник ты хороший, претензий к тебе особо нет. Так что собирайся и завтра же с утра езжай отдыхать. Путёвку мы тебе дадим. Так что не переживай. А. Чуть не забыл. Как приедешь - зайди в местное почтовое отделение. Ну давай! Удачного отдыха!^^
	^^]],
	obj = { vobj('continue','{Дальше}') },
	act = function()
		set_music('music.mod', 0);
		return walk('enterToTheHotel');
	end,
}
