-- Эпизод 1.


-- *** *** *** *** *** --
--      Персонажи      --
-- *** *** *** *** *** --

doctor = obj {
	nam = 'сотрудник';
	act = function()
		p 'Слышно несвязное бормотание: "Да куда подевался этот пароль... Неужели я его потерял... Может в гостинице оставил после симпозиума... Или дома...".';
	end;
	dsc = 'В коридоре стоит {сотрудник} предприятия в белом халате. Судя по его растерянному выражению лица, он явно что-то потерял.';
};

security = obj {
	nam = 'сторож';
	dsc = 'У входа стоит {сторож} и подозрительно косится на меня.';
	act = function()
		walkin 'securityDlg';
	end;
	used = function (s, w)
		if w == temporaryPass then
			p '-- Проходи.';
			disable('security');
			enable('securityWithPaper');
			enable('factory');
		end;
	end;
};

securityWithPaper = obj {
	nam = 'сторож с газетой';
	act = 'Похоже он не замечает ничего вокруг.';
	dsc = 'У входа стоит {сторож с газетой}.';
}: disable();

secretary = obj {
	nam = 'секретарша';
	act = 'Она так увлечена своим делом, что не замечает меня.';
	dsc = 'За столом сидит {секретарша} и с увлечением красит ногти.';
	used = function (s, w)
		if w == chocolate then
			p 'Я дал секретарше экспериментальную шоколадку. Она взяла её, попробовала кусочек и с выпученными глазами убежала в неизвестном направлении.';
			remove ( 'chocolate', me() );
			enable('extension');
			disable('secretary');
		end;
	end;
};

romantik = obj {
	nam = 'романтик';
	act = function()
		if fullGlass.step == 0 then
			p '-- Трезвый пьяному - не товарищ, - обижено сказал романтик.';
		end;
		if fullGlass.step == 1 then
			p '-- Я вижу тебя, брат! Но ты ещё слеп.';
		end;
		if fullGlass.step >= 2 then
			walkin 'romantikDlg';
		end;
	end;
	dsc = '"Великий {романтик}" сидит на стуле.';
}: disable();

body = obj {
	nam = 'подсобный рабочий';
	dsc = 'На полу лежит {тело} и изредка постанывает.';
	act = function()
		p 'От тела периодически исходят лёгкие нецензурные нотки, говорящие о нелёгкой судьбе закоренелого романтика в этом жестоком мире.';
	end;
	used = function (s, w)
		if w == postMessage then
			p 'Тело с трудом оторвалось от пола, огляделось вокруг, завалилось обратно на пол и захрапело.';
		else
			p 'Великий романтик находится сейчас не в самом лучшем виде.';
		end;
	end;
};

cleaningManager = obj {
	nam = 'уборщица';
	var {
		ok = '';
	};
	dsc = 'Рядом с лестницей стоит {уборщица}.';
	act = function()
		walkin 'cleaningManagerDlg';
	end;
	used = function (s, w)
		if w == fullBucket then
			p '-- Вот спасибо тебе, сынок! Вот помог бабушке! На тебе за это (даёт лампочку) - пригодится!';
			take ('lamp');
			remove ('fullBucket', me() );
			cleaningManager.ok = 'ok';
			disable(cleaningManager);
		else
			p '-- Ась? Что у тебя там? Не вижу без очков-то...';
		end;
	end;
};

womanAdministratorNearFountain = obj {
	nam = 'тётка-администратор';
	dsc = 'Около фонтана вопит {тётка-администратор}. Из её причитаний понятно только, что "мать", "за ногу" и "фонтан".';
	act = 'Лучше её сейчас не беспокоить.';
}: disable();

womanAdministrator = obj {
	nam = 'тётка-администратор';
	dsc = 'За стойкой сидит упитанная {тётка-администратор}. Её приветливо-суровое лицо не выражает никаких эмоций.';
	act = function()
		walkin 'womanAdministratorDlg';
	end;
	used = function (s, w)
		if w == documents then
			womanAdministratorDlg:poff('doc1');
			womanAdministratorDlg:poff('doc2');
			womanAdministratorDlg:pon('doc3');
			walkin 'womanAdministratorDlg';
		else
			p '-- Чего ты мне тут суёшь-то?!';
		end;
	end;
};

boy = obj {
	nam = 'мальчик';
	dsc = 'На лавочке сидит {мальчик} и задумчиво вертит в руках потрёпанную ромашку.';
	act = function()
		walkin 'boyDlg';
	end;
};

illusionist = obj {
	nam = 'фокусник';
	act = function()
		p 'Фокусник снял свой головной убор, достал кролика из клетки и бросил его в это волшебное устройство. Немного погодя, пошарив рукой в недрах шляпы, вытащил оттуда пирожок с крольчатиной. После чего, накрыл плащом клетку. Несколько быстрых взмахов руками и в клетке снова появился кролик.';
	end;
	dsc = 'Из окошка смотрит скучающий {фокусник}.';
};

postManager = obj {
	nam = 'почтовый работник';
	dsc = 'За стойкой сидит {почтовый работник}. На лице отчётливо видны все 3 класса образования.';
	act = function()
		walkin 'postManagerDlg';
	end;
	used = function (s, w)
		if w == fullBlank457 then
			if fullBlank457.g1 == 'ФИО' and
				fullBlank457.g2 == 'Весенний бриз' and
				fullBlank457.g3 == '457' and
				fullBlank457.g4 == 'Подпись' and
				fullBlank457.g5 == 'Прочерк' then
					p '-- Кажись всё правильно. Вот ваше письмо.';
					take ('postMessage');
					remove ('fullBlank457', me() );
			else
					p '-- Да кто ж так бланки заполняет-то?! Переписывайте!';
					take ('cleanBlank457');
					remove ('fullBlank457', me() );
			end;
		else
			p 'Не будем отвлекать человека всякими глупостями.';
		end;
	end;
};
